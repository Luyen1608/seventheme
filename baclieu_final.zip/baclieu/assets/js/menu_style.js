$(".filter-main-btn").append("<div class='cart-btn' data-content='10'><img src='../../assets/img/cart-2.svg' alt=''></div>");
$("body").append("<ul class='nk-sticky-toolbar'><li class='demo-purchase'><a href='/Cart'><img src='../../assets/img/cart-red.svg' alt=''></a></li></ul>");
